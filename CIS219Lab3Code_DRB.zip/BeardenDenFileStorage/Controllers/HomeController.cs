﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BeardenDenFileStorage.Controllers
{
    public class HomeController
    {
        public string Index()
        {
            return "Project \"BearDen File Storage\" Controller is alive!";
        }
    }
}
